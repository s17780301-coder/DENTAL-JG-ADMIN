-- DENTAL JG · esquema inicial para Supabase
-- Ejecuta en Supabase > SQL Editor. Las tablas requieren usuario autenticado.
create extension if not exists pgcrypto;

create table if not exists public.patients (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text default '',
  treatment text default '',
  total numeric(12,2) not null default 0 check (total >= 0),
  paid numeric(12,2) not null default 0 check (paid >= 0),
  installments integer not null default 0,
  installment_amount numeric(12,2) not null default 0,
  policy_number text default '',
  clinic text default '',
  source_device text default 'DENTAL JG',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid references public.patients(id) on delete set null,
  patient_name text not null default '',
  amount numeric(12,2) not null check (amount > 0),
  concept text not null default 'Abono',
  reference text default '',
  paid_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  source_device text not null default 'DENTAL JG'
);
create index if not exists patients_name_idx on public.patients using gin (to_tsvector('simple', coalesce(name,'')));
create index if not exists payments_paid_at_idx on public.payments (paid_at desc);

alter table public.patients enable row level security;
alter table public.payments enable row level security;
-- Para el primer despliegue, cualquier usuario autenticado puede consultar y editar.
-- Crea solo usuarios de confianza en Authentication. Añade políticas por clínica/rol antes de ampliar el acceso.
drop policy if exists "authenticated users manage patients" on public.patients;
create policy "authenticated users manage patients" on public.patients for all to authenticated using (true) with check (true);
drop policy if exists "authenticated users manage payments" on public.payments;
create policy "authenticated users manage payments" on public.payments for all to authenticated using (true) with check (true);

-- Habilitar actualizaciones en tiempo real desde Database > Publications si no aparece ya habilitado.
alter publication supabase_realtime add table public.patients;
alter publication supabase_realtime add table public.payments;
