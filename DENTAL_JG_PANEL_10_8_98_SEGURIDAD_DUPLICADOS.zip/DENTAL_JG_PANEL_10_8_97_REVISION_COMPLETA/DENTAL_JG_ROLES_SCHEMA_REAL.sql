-- DENTAL JG — diagnóstico de esquema de roles confirmado.
-- La tabla usa id_usuario, role y creado_at (no user_id).
-- Este archivo es de SOLO LECTURA: no asigna roles ni cambia permisos.
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'app_user_roles'
ORDER BY ordinal_position;

SELECT role, count(*) AS usuarios_con_ese_rol
FROM public.app_user_roles
GROUP BY role
ORDER BY role;

-- Para comprobar una cuenta concreta, reemplaza el correo de forma manual:
-- SELECT u.email, r.id_usuario, r.role, r.creado_at
-- FROM auth.users AS u
-- JOIN public.app_user_roles AS r ON r.id_usuario = u.id
-- WHERE lower(u.email) = lower('CORREO_DE_LA_CUENTA');
