-- DENTAL JG 10.8.98 — controles contra duplicados.
-- IMPORTANTE: revisar el resultado de los bloques de diagnóstico antes de crear índices.
-- Este archivo NO borra, fusiona ni modifica pagos existentes.
-- La identidad de póliza se considera única DENTRO de cada clínica.

BEGIN;

-- 1) Diagnóstico obligatorio: si hay duplicados históricos, se aborta la migración
-- y se informa qué combinación clínica/póliza debe revisarse manualmente.
DO $$
DECLARE
  duplicados text;
BEGIN
  SELECT string_agg(format('clínica=%s, póliza=%s, cantidad=%s', clinic, policy_number, n), E'\n')
    INTO duplicados
  FROM (
    SELECT min(trim(clinic)) AS clinic, min(trim(policy_number)) AS policy_number, count(*) AS n
    FROM public.patients
    WHERE nullif(trim(clinic), '') IS NOT NULL
      AND nullif(trim(policy_number), '') IS NOT NULL
    GROUP BY lower(trim(clinic)), lower(trim(policy_number))
    HAVING count(*) > 1
    ORDER BY count(*) DESC
    LIMIT 30
  ) d;

  IF duplicados IS NOT NULL THEN
    RAISE EXCEPTION 'No se creó el índice: hay pólizas duplicadas por clínica. Revisión manual necesaria:%', E'\n' || duplicados;
  END IF;
END $$;

-- La base de datos, no solo el navegador, bloquea dos altas simultáneas de la misma póliza.
CREATE UNIQUE INDEX IF NOT EXISTS uq_patients_clinic_policy_normalized
  ON public.patients (lower(trim(clinic)), lower(trim(policy_number)))
  WHERE nullif(trim(clinic), '') IS NOT NULL
    AND nullif(trim(policy_number), '') IS NOT NULL;

-- Evita duplicar clínicas por mayúsculas/minúsculas o espacios.
DO $$
DECLARE duplicados text;
BEGIN
  SELECT string_agg(format('%s (%s registros)', name, n), E'\n') INTO duplicados
  FROM (
    SELECT min(trim(name)) AS name, count(*) AS n
    FROM public.clinics
    WHERE nullif(trim(name), '') IS NOT NULL
    GROUP BY lower(trim(name))
    HAVING count(*) > 1
    ORDER BY count(*) DESC
    LIMIT 30
  ) d;
  IF duplicados IS NOT NULL THEN
    RAISE EXCEPTION 'No se creó el índice de clínicas: hay nombres duplicados. Revisión manual necesaria:%', E'\n' || duplicados;
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS uq_clinics_name_normalized
  ON public.clinics (lower(trim(name)))
  WHERE nullif(trim(name), '') IS NOT NULL;

COMMIT;

-- SEGURIDAD DE PAGOS:
-- El panel 10.8.98 envía p_request_id al RPC register_dental_jg_payment.
-- No se incluye aquí una sustitución automática del RPC porque el esquema completo
-- de public.payments y la función vigente deben confirmarse antes de alterar una
-- operación financiera. No crees un INSERT alternativo desde el navegador.
-- Próximo paso requerido: revisar definición actual del RPC y columnas de payments,
-- luego agregar idempotencia persistente (request_id UNIQUE) y actualización de
-- patients.paid en la misma transacción, con bloqueo de fila y validación de rol.
