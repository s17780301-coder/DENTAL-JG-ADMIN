import { createClient, type SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2";

/**
 * DENTAL JG — administrar-usuarios, reconstrucción completa.
 * Tabla confirmada en el proyecto: public.app_user_roles(id_usuario uuid, role text, creado_at timestamptz).
 * El contrato HTTP conserva user_id como nombre del campo de entrada para compatibilidad con users.js;
 * user_id NO se usa como nombre de columna de la tabla.
 */
const ALLOWED_ORIGINS = new Set(["https://s17780301-coder.github.io"]);
const VALID_ROLES = new Set(["admin", "cobranza", "registro"]);
const ROLE_TABLE = "app_user_roles";

function cors(req: Request): HeadersInit {
  const origin = req.headers.get("Origin") ?? "";
  return {
    "Access-Control-Allow-Origin": ALLOWED_ORIGINS.has(origin) ? origin : "null",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin",
  };
}
function reply(req: Request, body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors(req), "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  });
}
function secret(name: string): string | null {
  const raw = Deno.env.get(name);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (typeof parsed === "string") return parsed;
    if (parsed && typeof parsed === "object") {
      if (typeof parsed.default === "string") return parsed.default;
    }
  } catch { return raw; }
  return null;
}
function normRole(v: unknown): string { return String(v ?? "").trim().toLowerCase(); }
function validEmail(v: string): boolean { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
function uniqueRoles(values: unknown[]): string[] {
  return [...new Set(values.map(normRole).filter((r) => VALID_ROLES.has(r)))];
}
async function readRoles(admin: SupabaseClient, userId: string) {
  return await admin.from(ROLE_TABLE).select("role").eq("id_usuario", userId);
}
async function adminCount(admin: SupabaseClient) {
  return await admin.from(ROLE_TABLE).select("id_usuario", { count: "exact", head: true }).eq("role", "admin");
}
async function addMissingRoles(admin: SupabaseClient, userId: string, desired: string[], current: string[]) {
  const missing = desired.filter((r) => !current.includes(r));
  for (const role of missing) {
    // No suponemos que exista una restricción UNIQUE; comprobamos antes de insertar.
    const { data, error: checkError } = await admin.from(ROLE_TABLE)
      .select("id_usuario").eq("id_usuario", userId).eq("role", role).limit(1);
    if (checkError) throw new Error(`No se pudo comprobar el rol ${role}: ${checkError.message}`);
    if (!data?.length) {
      const { error } = await admin.from(ROLE_TABLE).insert({ id_usuario: userId, role });
      if (error) throw new Error(`No se pudo asignar el rol ${role}: ${error.message}`);
    }
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(req) });
  const origin = req.headers.get("Origin");
  if (origin && !ALLOWED_ORIGINS.has(origin)) return reply(req, { error: "Origen no autorizado." }, 403);
  if (req.method !== "POST") return reply(req, { error: "Usa una solicitud POST." }, 405);

  const url = Deno.env.get("SUPABASE_URL");
  const anon = secret("SUPABASE_PUBLISHABLE_KEYS") ?? secret("SUPABASE_PUBLISHABLE_KEY") ?? secret("SUPABASE_ANON_KEY") ?? req.headers.get("apikey");
  const service = secret("SUPABASE_SECRET_KEYS") ?? secret("SUPABASE_SECRET_KEY") ?? secret("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !anon || !service) {
    console.error("Configuración ausente", { hasUrl: !!url, hasPublicKey: !!anon, hasServiceKey: !!service });
    return reply(req, { error: "Configuración incompleta de la Edge Function. Verifica SUPABASE_URL, la clave pública y la clave secreta del servidor en Secrets." }, 500);
  }
  const authorization = req.headers.get("Authorization");
  if (!authorization?.startsWith("Bearer ")) return reply(req, { error: "Debes iniciar sesión." }, 401);

  const callerClient = createClient(url, anon, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: callerData, error: authError } = await callerClient.auth.getUser();
  if (authError || !callerData.user) return reply(req, { error: `Sesión no válida: ${authError?.message ?? "usuario no identificado"}` }, 401);
  const caller = callerData.user;
  const admin = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } });

  let body: Record<string, unknown>;
  try { body = await req.json(); }
  catch { return reply(req, { error: "El cuerpo de la solicitud no contiene JSON válido." }, 400); }
  const action = String(body.action ?? "").trim().toLowerCase();

  // El panel usa my_roles al iniciar sesión; solo devuelve los roles del propio usuario.
  if (action === "my_roles") {
    const { data, error } = await readRoles(admin, caller.id);
    if (error) {
      console.error("my_roles: app_user_roles", error.message);
      return reply(req, { error: `No se pudieron leer tus roles en app_user_roles: ${error.message}` }, 500);
    }
    return reply(req, { roles: uniqueRoles((data ?? []).map((r: { role: string }) => r.role)) });
  }

  // Todas las operaciones de administración exigen admin validado en el servidor.
  const { data: callerRoles, error: callerRoleError } = await readRoles(admin, caller.id);
  if (callerRoleError) {
    console.error("admin role check failed", callerRoleError.message);
    return reply(req, { error: `No se pudo comprobar tu rol en app_user_roles (columna id_usuario): ${callerRoleError.message}` }, 500);
  }
  if (!uniqueRoles((callerRoles ?? []).map((r: { role: string }) => r.role)).includes("admin")) {
    return reply(req, { error: "Acceso denegado: se requiere el rol admin." }, 403);
  }

  try {
    if (action === "list_users") {
      const { data: authData, error: listError } = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
      if (listError) throw new Error(`No se pudieron listar las cuentas de Auth: ${listError.message}`);
      const { data: roleRows, error: rolesError } = await admin.from(ROLE_TABLE).select("id_usuario, role, creado_at");
      if (rolesError) throw new Error(`No se pudieron leer los roles: ${rolesError.message}`);
      const byUser = new Map<string, string[]>();
      for (const row of roleRows ?? []) {
        const id = String(row.id_usuario);
        const roles = byUser.get(id) ?? [];
        const role = normRole(row.role);
        if (VALID_ROLES.has(role) && !roles.includes(role)) roles.push(role);
        byUser.set(id, roles);
      }
      const users = (authData?.users ?? []).map((u) => {
        const roles = byUser.get(u.id) ?? [];
        return { id: u.id, email: u.email ?? "", created_at: u.created_at, last_sign_in_at: u.last_sign_in_at ?? null,
          disabled: !!u.banned_until && new Date(u.banned_until).getTime() > Date.now(), roles, role: roles[0] ?? "sin_asignar" };
      });
      return reply(req, { users });
    }

    if (action === "create_user") {
      const email = String(body.email ?? "").trim().toLowerCase();
      const password = String(body.password ?? "");
      const role = normRole(body.role);
      if (!validEmail(email)) return reply(req, { error: "Escribe un correo electrónico válido." }, 400);
      if (password.length < 8) return reply(req, { error: "La contraseña temporal debe tener al menos 8 caracteres." }, 400);
      if (!VALID_ROLES.has(role)) return reply(req, { error: "Rol no válido. Usa admin, cobranza o registro." }, 400);
      const { data, error } = await admin.auth.admin.createUser({ email, password, email_confirm: true });
      if (error || !data.user) throw new Error(`No se pudo crear la cuenta: ${error?.message ?? "sin usuario devuelto"}`);
      try { await addMissingRoles(admin, data.user.id, [role], []); }
      catch (e) { await admin.auth.admin.deleteUser(data.user.id); throw e; }
      return reply(req, { message: "Cuenta creada y rol asignado.", user: { id: data.user.id, email: data.user.email, role } }, 201);
    }

    if (action === "set_roles" || action === "set_role") {
      const id = String(body.user_id ?? "").trim(); // API del panel; no es nombre de columna.
      const submitted = action === "set_roles" && Array.isArray(body.roles) ? body.roles : [body.role];
      const desired = uniqueRoles(submitted as unknown[]);
      if (!id) return reply(req, { error: "Falta user_id." }, 400);
      if (!desired.length || desired.length !== submitted.length) return reply(req, { error: "Selecciona al menos un rol válido: admin, cobranza o registro." }, 400);
      const { data: target, error: targetError } = await admin.auth.admin.getUserById(id);
      if (targetError || !target.user) return reply(req, { error: "La cuenta indicada no existe." }, 404);
      const { data: rows, error } = await readRoles(admin, id);
      if (error) throw new Error(`No se pudieron leer los roles actuales: ${error.message}`);
      const current = uniqueRoles((rows ?? []).map((r: { role: string }) => r.role));
      const removingAdmin = current.includes("admin") && !desired.includes("admin");
      if (removingAdmin) {
        if (id === caller.id) return reply(req, { error: "No puedes quitarte tu propio rol de administrador." }, 400);
        const { count, error: countError } = await adminCount(admin);
        if (countError) throw new Error(`No se pudo contar administradores: ${countError.message}`);
        if ((count ?? 0) <= 1) return reply(req, { error: "No puedes quitar el rol al último administrador." }, 400);
      }
      await addMissingRoles(admin, id, desired, current);
      const remove = current.filter((r) => !desired.includes(r));
      if (remove.length) {
        const { error: deleteError } = await admin.from(ROLE_TABLE).delete().eq("id_usuario", id).in("role", remove);
        if (deleteError) throw new Error(`Se asignaron los roles nuevos, pero no se pudieron retirar los anteriores: ${deleteError.message}`);
      }
      return reply(req, { message: "Roles actualizados.", roles: desired });
    }

    if (action === "set_active") {
      const id = String(body.user_id ?? "").trim();
      const active = body.active;
      if (!id || typeof active !== "boolean") return reply(req, { error: "Indica user_id y active como true o false." }, 400);
      if (id === caller.id && !active) return reply(req, { error: "No puedes desactivar tu propia cuenta." }, 400);
      const { data: target, error: targetError } = await admin.auth.admin.getUserById(id);
      if (targetError || !target.user) return reply(req, { error: "La cuenta indicada no existe." }, 404);
      if (!active) {
        const { data: roles, error } = await readRoles(admin, id);
        if (error) throw new Error(`No se pudieron comprobar los roles de la cuenta: ${error.message}`);
        if (uniqueRoles((roles ?? []).map((r: { role: string }) => r.role)).includes("admin")) {
          const { count, error: countError } = await adminCount(admin);
          if (countError) throw new Error(`No se pudo contar administradores: ${countError.message}`);
          if ((count ?? 0) <= 1) return reply(req, { error: "No puedes desactivar al último administrador." }, 400);
        }
      }
      const { error } = await admin.auth.admin.updateUserById(id, { ban_duration: active ? "none" : "876000h" });
      if (error) throw new Error(`No se pudo ${active ? "activar" : "desactivar"} la cuenta: ${error.message}`);
      return reply(req, { message: active ? "Cuenta activada." : "Cuenta desactivada." });
    }

    if (action === "reset_password") {
      const id = String(body.user_id ?? "").trim();
      const password = String(body.password ?? "");
      if (!id) return reply(req, { error: "Falta user_id." }, 400);
      if (password.length < 8) return reply(req, { error: "La nueva contraseña debe tener al menos 8 caracteres." }, 400);
      const { data: target, error: targetError } = await admin.auth.admin.getUserById(id);
      if (targetError || !target.user) return reply(req, { error: "La cuenta indicada no existe." }, 404);
      const { error } = await admin.auth.admin.updateUserById(id, { password });
      if (error) throw new Error(`No se pudo restablecer la contraseña: ${error.message}`);
      return reply(req, { message: "Contraseña restablecida correctamente." });
    }

    if (action === "delete_user") {
      const id = String(body.user_id ?? "").trim();
      if (!id) return reply(req, { error: "Falta user_id." }, 400);
      if (id === caller.id) return reply(req, { error: "No puedes eliminar tu propia cuenta de administración." }, 400);
      const { data: target, error: targetError } = await admin.auth.admin.getUserById(id);
      if (targetError || !target.user) return reply(req, { error: "La cuenta indicada no existe." }, 404);
      const { data: roles, error } = await readRoles(admin, id);
      if (error) throw new Error(`No se pudieron comprobar los roles antes de eliminar: ${error.message}`);
      if (uniqueRoles((roles ?? []).map((r: { role: string }) => r.role)).includes("admin")) {
        const { count, error: countError } = await adminCount(admin);
        if (countError) throw new Error(`No se pudo contar administradores: ${countError.message}`);
        if ((count ?? 0) <= 1) return reply(req, { error: "No puedes eliminar al último administrador." }, 400);
      }
      // Borrar primero sus permisos de la tabla y luego la cuenta Auth.
      const { error: roleDeleteError } = await admin.from(ROLE_TABLE).delete().eq("id_usuario", id);
      if (roleDeleteError) throw new Error(`No se pudieron retirar los roles de la cuenta: ${roleDeleteError.message}`);
      const { error: authDeleteError } = await admin.auth.admin.deleteUser(id);
      if (authDeleteError) throw new Error(`No se pudo eliminar la cuenta de Auth: ${authDeleteError.message}`);
      return reply(req, { message: "Cuenta eliminada correctamente." });
    }

    return reply(req, { error: "Acción no reconocida.", actions: ["my_roles", "list_users", "create_user", "set_roles", "set_role", "set_active", "reset_password", "delete_user"] }, 400);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`administrar-usuarios action=${action} failed:`, message);
    return reply(req, { error: message }, 500);
  }
});
