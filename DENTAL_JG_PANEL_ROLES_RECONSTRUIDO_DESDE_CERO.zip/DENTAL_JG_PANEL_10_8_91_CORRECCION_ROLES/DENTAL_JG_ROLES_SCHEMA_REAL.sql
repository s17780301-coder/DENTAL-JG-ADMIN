-- DENTAL JG — asignar rol registro usando la estructura REAL de la tabla actual.
-- Es solo un ejemplo para el usuario de Registro. Cambia el correo si corresponde.
-- La tabla confirmada es app_user_roles(id_usuario, role, creado_at), NO (user_id, role).
DO $$
DECLARE
  correo_objetivo text := 's17780301@gmail.com';
  usuario_objetivo uuid;
BEGIN
  SELECT id INTO usuario_objetivo
  FROM auth.users
  WHERE lower(email) = lower(correo_objetivo)
  LIMIT 1;

  IF usuario_objetivo IS NULL THEN
    RAISE EXCEPTION 'No existe una cuenta Auth con el correo % en este proyecto. Verifica Authentication > Users.', correo_objetivo;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.app_user_roles
    WHERE id_usuario = usuario_objetivo AND lower(role) = 'registro'
  ) THEN
    INSERT INTO public.app_user_roles (id_usuario, role)
    VALUES (usuario_objetivo, 'registro');
  END IF;
END $$;

SELECT u.email, r.id_usuario, r.role, r.creado_at
FROM auth.users AS u
JOIN public.app_user_roles AS r ON r.id_usuario = u.id
WHERE lower(u.email) = lower('s17780301@gmail.com');
