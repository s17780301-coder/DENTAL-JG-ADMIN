DENTAL JG 1.0.6 — PANEL WEB TURQUESA

Este ZIP contiene los archivos del panel web para publicar en GitHub Pages, incluyendo index.html, styles.css, app.js, config.js, users.js, iconos, manifiesto, service worker y la Edge Function administrar-usuarios.

PUBLICACIÓN
1. Sube este ZIP a la raíz del repositorio s17780301-coder/DENTAL-JG-ADMIN.
2. En Actions, ejecuta “Descomprimir ZIP y publicar archivos” si necesitas extraerlo a la raíz. Para publicar solo con el flujo de deploy, asegúrate de que los archivos web requeridos queden en la raíz.
3. Confirma que “Publicar panel DENTAL JG” finalice en success y abre https://s17780301-coder.github.io/DENTAL-JG-ADMIN/.
4. Comprueba login, navegación por rol y conexión a Supabase. La compilación exitosa del sitio no valida por sí sola permisos ni datos de Supabase.

IMPORTANTE: la migración SQL integrada todavía debe validarse contra una copia de la base y con las APK nuevas antes de aplicarla en producción.

Validación local: ZIP íntegro; index.html, app.js y styles.css incluidos.
